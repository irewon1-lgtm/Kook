import { chromium } from '/workspace/kr4-pc-web/web/node_modules/playwright/index.mjs';
import { readFileSync, writeFileSync, appendFileSync, mkdirSync } from 'node:fs';
import { createHash } from 'node:crypto';
import assert from 'node:assert/strict';
const dir='/workspace/kr4-pc-work/real-background-observer';
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
const expected=JSON.parse(readFileSync(dir+'/changed-to-unranked.json'))[0];
const beforeManifest=JSON.parse(readFileSync(dir+'/official-manifest.json'));
const newQuant=JSON.parse(readFileSync(dir+'/new-main-quant.json'));
const browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true});
const context=await browser.newContext({viewport:{width:1365,height:1000},locale:'ko-KR',timezoneId:'Asia/Seoul'});
const page=await context.newPage();
const navigationEvents=[], receptionEvents=[], errors=[];let documentLoads=0;const responseBodies=new Map();
const emit=value=>{const event={observedAt:new Date().toISOString(),...value};appendFileSync(dir+'/events.jsonl',JSON.stringify(event)+'\n');console.log(JSON.stringify(event));};
page.on('domcontentloaded',()=>{documentLoads++;emit({event:'DOCUMENT_LOADED',documentLoads});});
page.on('framenavigated',frame=>{if(frame===page.mainFrame()){navigationEvents.push({at:new Date().toISOString(),url:frame.url()});emit({event:'MAIN_FRAME_NAVIGATION',url:frame.url()});}});
page.on('pageerror',error=>{errors.push(error.message);emit({event:'PAGE_ERROR',message:error.message});});
page.on('response',async response=>{
 const url=response.url();if(!/(?:manifest|stocks|rankings)\.json(?:\?|$)/.test(url))return;
 try{const body=await response.body();const digest=sha(body);const name=new URL(url).pathname.split('/').at(-1);const file=`reception-${name.replace('.json','')}-${digest}.json`;
  if(!responseBodies.has(digest)){writeFileSync(dir+'/'+file,body);responseBodies.set(digest,file);}
  const meta={at:new Date().toISOString(),url,status:response.status(),sha256:digest,bytes:body.length,file};receptionEvents.push(meta);appendFileSync(dir+'/http-receptions.jsonl',JSON.stringify(meta)+'\n');
  if(name==='manifest.json'){const m=JSON.parse(body);emit({event:'ACTUAL_APP_MANIFEST_RESPONSE',...meta,snapshotDate:m.snapshotDate,sourceCommit:m.sourceCommit,completeCount:m.coverage?.completeCount});}
 }catch(error){emit({event:'PASSIVE_RESPONSE_CAPTURE_ERROR',message:error.message,url});}
});
await page.goto('https://irewon1-lgtm.github.io/Kook/#ranking',{waitUntil:'domcontentloaded'});
await page.waitForFunction(()=>document.querySelector('[data-testid="kr4-app"]')?.getAttribute('data-source')==='LIVE'&&document.querySelector('[data-testid="kr4-app"]')?.getAttribute('data-refreshing')==='false',null,{timeout:120000});
const app=page.getByTestId('kr4-app');const uiCommit=await app.getAttribute('data-ui-commit');assert.ok(uiCommit?.startsWith('d7272be'),'Actual current319 UI required: '+uiCommit);
await page.getByRole('searchbox').fill(expected.code);
for(const id of ['M01','M02','M03','M04'])assert.equal(await page.getByTestId('metric-toggle-'+id).getAttribute('aria-pressed'),'true');
const row=page.locator('.ranking-stock-table .stock-row');await row.waitFor();assert.equal(await row.count(),1);assert.equal(await row.locator('.rank-badge').innerText(),expected.oldRank+'위');
const originalDocument=await page.evaluateHandle(()=>document);const timeOrigin=await page.evaluate(()=>performance.timeOrigin);const baseDocumentLoads=documentLoads;
async function snapshot(label){
 const identity=await page.evaluate(original=>({sameDocument:original===document,timeOrigin:performance.timeOrigin,navigationEntries:performance.getEntriesByType('navigation').map(x=>({name:x.name,type:x.type,startTime:x.startTime})),url:location.href,visibilityState:document.visibilityState}),originalDocument);
 return {kind:'ACTUAL_OFFICIAL_PUBLICATION_BACKGROUND_OBSERVER',controlled:false,networkRoutesInstalled:false,clockModified:false,manualRefreshClicks:0,pageReloadCalls:0,label,capturedAt:new Date().toISOString(),uiCommit:await app.getAttribute('data-ui-commit'),sourceCommit:await app.getAttribute('data-source-commit'),source:await app.getAttribute('data-source'),refreshing:await app.getAttribute('data-refreshing'),dataBase:await app.getAttribute('data-data-base'),sourceSummary:await page.locator('.ranking-source-summary').innerText(),counts:await page.locator('.universe-counts:visible').innerText(),row:await row.innerText(),query:await page.getByRole('searchbox').inputValue(),identity,documentLoads,navigationEvents:[...navigationEvents],browserVersion:browser.version(),runnerPlatform:process.platform,physicalHardwareClaim:false,selectedStock:expected,errors:[...errors]};
}
const before=await snapshot('BEFORE_ARMED');assert.match(before.counts,/2,376/);assert.match(before.counts,/273/);assert.match(before.sourceSummary,/2026-11-05/);assert.equal(before.sourceCommit,beforeManifest.sourceCommit);assert.ok(before.identity.sameDocument);
await page.screenshot({path:dir+'/before.png',fullPage:true});writeFileSync(dir+'/before.json',JSON.stringify(before,null,2)+'\n');writeFileSync(dir+'/ARMED.json',JSON.stringify({armedAt:new Date().toISOString(),pid:process.pid,uiCommit,code:expected.code,beforeSourceCommit:before.sourceCommit,documentLoads,timeOrigin},null,2)+'\n');emit({event:'ARMED',uiCommit,sourceCommit:before.sourceCommit,code:expected.code,oldRank:expected.oldRank,oldScore:expected.oldScore,oldComplete:2376,newExpectedComplete:2370,timeOrigin});
let lastObservation='',seenNew=false;
for(let iteration=0;iteration<720;iteration++){
 // This observer only reads DOM every ten seconds. The app's own real five-minute
 // interval performs all refreshes; no timer, focus, network, or UI refresh is triggered.
 await new Promise(resolve=>setTimeout(resolve,10000));
 const current=await snapshot('WAITING_REAL_APP_POLL');assert.ok(current.identity.sameDocument,'Document replaced');assert.equal(current.identity.timeOrigin,timeOrigin);assert.equal(documentLoads,baseDocumentLoads,'Document loaded again');assert.equal(current.query,expected.code,'Search input lost');assert.equal(current.uiCommit,uiCommit,'Mounted UI code changed');
 const observation=JSON.stringify([current.sourceCommit,current.sourceSummary,current.counts,current.row,current.refreshing]);
 if(observation!==lastObservation){emit({event:'DOM_OBSERVATION',...current});writeFileSync(dir+'/latest.json',JSON.stringify(current,null,2)+'\n');lastObservation=observation;}
 if(current.sourceSummary.includes(newQuant.snapshot_date_kst)&&current.counts.includes('2,370')&&current.counts.includes('279')&&current.row.includes('보류')&&current.row.includes('미산출')&&current.row.includes(expected.newM03.reason)){
  assert.equal(await row.locator('.rank-badge').count(),0);assert.equal(await row.locator('.rank-pending').innerText(),'보류');
  const manifestReception=[...receptionEvents].reverse().find(x=>x.file.startsWith('reception-manifest-')&&JSON.parse(readFileSync(dir+'/'+x.file)).snapshotDate===newQuant.snapshot_date_kst);assert.ok(manifestReception,'Actual new app manifest response not captured');
  const manifest=JSON.parse(readFileSync(dir+'/'+manifestReception.file));const stockHash=manifest.files['stocks.json'].sha256;const stocksReception=[...receptionEvents].reverse().find(x=>x.file.startsWith('reception-stocks-')&&x.sha256===stockHash);assert.ok(stocksReception,'Actual new verified stocks response not captured');
  const stocks=JSON.parse(readFileSync(dir+'/'+stocksReception.file));assert.equal(stocks.length,2649);const actual=stocks.find(x=>x.issuerId===expected.code);assert.equal(actual.rankOrder,null);assert.equal(actual.compositeScore,null);assert.equal(actual.m03Per.rawValue,null);assert.equal(actual.m03Per.reason,expected.newM03.reason);assert.equal(actual.asOfDate,newQuant.snapshot_date_kst);assert.equal(manifest.coverage.completeCount,2370);
  const rankingsResponse=await context.request.get(new URL((manifest.basePath||'')+'rankings.json',current.dataBase).href);assert.equal(rankingsResponse.status(),200);const rankingBytes=await rankingsResponse.body();assert.equal(sha(rankingBytes),manifest.files['rankings.json'].sha256);writeFileSync(dir+'/after-original-rankings.json',rankingBytes);const rankings=JSON.parse(rankingBytes);assert.equal(rankings['15'][expected.code].rank,null);assert.equal(rankings['15'][expected.code].score,null);
  await page.screenshot({path:dir+'/after.png',fullPage:true});const after={...current,label:'AFTER_REAL_BACKGROUND_PASS',manifestReception,stocksReception,actualChangedStock:actual,originalRanking:rankings['15'][expected.code],newManifest:manifest,assertions:{sameDocument:true,noReload:true,noClockChanges:true,noRoutes:true,naturalAppPoll:true,complete2370:true,missing279:true,rankHeld:true,realMissingReason:true,all2649Stocks:true,stockHashVerified:true,originalRankingHashVerified:true}};writeFileSync(dir+'/after.json',JSON.stringify(after,null,2)+'\n');writeFileSync(dir+'/PASS.json',JSON.stringify({passedAt:new Date().toISOString(),sameDocument:true,timeOrigin,documentLoads,uiCommit,beforeSourceCommit:before.sourceCommit,afterSourceCommit:current.sourceCommit,code:expected.code,beforeRank:expected.oldRank,afterRank:null,beforeComplete:2376,afterComplete:2370,missing:279,manifestSha256:manifestReception.sha256,stocksSha256:stocksReception.sha256,rankingsSha256:sha(rankingBytes)},null,2)+'\n');emit({event:'PASS_REAL_COLLECT_TO_BROWSER_BACKGROUND',code:expected.code,beforeRank:expected.oldRank,afterRank:null,beforeComplete:2376,afterComplete:2370,sourceCommit:current.sourceCommit,sameDocument:true});seenNew=true;break;
 }
}
if(!seenNew){emit({event:'TIMEOUT_NO_NEW_PUBLICATION'});process.exitCode=2;}
await browser.close();
